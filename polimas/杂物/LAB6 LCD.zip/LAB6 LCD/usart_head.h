void uart_initialize(void);
